<?php

class IndexController extends Zend_Controller_Action
    {

    public function init()
        {
                /* Initialize action controller here
        Zend_Dojo::enableView($this->view);
        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('viewRenderer');
        $viewRenderer->setView($this->view);*/

        Zend_Dojo::enableView($this->view);
        $this->view->dojo()
                    ->addStyleSheetModule('dijit.themes.tundra')
                    ->setDjConfigOption('usePlainJson', true)
                    ->enable();
        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('ViewRenderer');
        $viewRenderer->setView($this->view);
        }

public function indexAction()
        {
        $listing = new Application_Model_DbTable_Listing();
        $this->view->listing = $listing->fetchAll();

        $form = $this->getForm();
        $this->view->form = $form;
                /*
        if ($this->_request->isPost()) 
                        {
            if ($form->isValid($_POST)) 
                                {
                $userId = $this->_getParam('userId');
                        } 
                        else 
                                {
                                $form->populate($_POST);
                                $this->view->form = $form;
                                }
                        } 
                else 
                        {
                        $this->view->form = $form;
                        }*/
        }

    public function getForm() 
        {
        $form = new Zend_Form;
        $userId = new Zend_Dojo_Form_Element_FilteringSelect('userId');
        $userId->setLabel('Select a user')
                ->setAutoComplete(true)
                ->setStoreId('userStore')
                ->setStoreType('dojo.data.ItemFileReadStore')
                ->setStoreParams(array('url'=>$this->view->baseUrl().'/index/list'))
                ->setAttrib("searchAttr", "username")
                ->setRequired(true);
        $submit = $form->createElement('submit', 'submit');

        $form->addElements(array($userId, $submit));

        return $form;
        }
	
    public function listAction()
        {
        $db = new Zend_Db_Adapter_Pdo_pgsql(array(
                'host'     => '127.0.0.1',
                'username' => 'vtrao',
                'password' => 'venkiss',
                'dbname'   => 'plutolist'
                            ));

            $result = $db->fetchAll("SELECT * FROM pll_user");
            $data = new Zend_Dojo_Data('id', $result);
            $this->_helper->autoCompleteDojo($data);
        }

    public function searchAction()
        {
            // action body
        }

    public function editAction()
        {
            // action body
        }

    public function deleteAction()
        {
            // action body
        }
    }









