<?php
class Application_Model_DbTable_Listing extends Zend_Db_Table_Abstract
    {
    protected $_name = 'pll_listing';

    public function getListing($listing_id) 
        {
        $listing_id = (int)$listing_id;
        $row = $this->fetchRow('listing_id = ' . $listing_id);
        if (!$row) 
            {
            throw new Exception("Could not find row $id");
            }
        return $row->toArray();   
        }

    public function addListing( $title, 
                                $description, 
                                $price, 
                                $quantity, 
                                $negotiable, 
                                $product_age, 
                                $contact_email, 
                                $home_number, 
                                $mobile_number, 
                                $pref_contact_timing, 
                                $fcat_id, 
                                $fsubcat_id, 
                                $farea_id, 
                                $fcity_id, 
                                $fstate_id, 
                                $fcountry_id )
        {
        $data = array(
                    'title' => $title,
                    'description'=>$description,
                    'price'=>$price, 
                    'quantity'=>$quantity, 
                    'negotiable'=>$negotiable, 
                    'product_age'=>$product_age, 
                    'contact_email'=>$contact_email, 
                    'home_number'=>$home_number, 
                    'mobile_number'=>$mobile_number, 
                    'pref_contact_timing'=>$pref_contact_timing, 
                    'fcat_id'=>$fcat_id, 
                    'fsubcat_id'=>$fsubcat_id, 
                    'farea_id'=>$farea_id, 
                    'fcity_id'=>$fcity_id, 
                    'fstate_id'=>$fstate_id, 
                    'fcountry_id'=>$fcountry_id,
                    );
        $this->insert($data);
        }

    public function updateListing(
                                    $listing_id,
                                    $title, 
                                    $description, 
                                    $price, 
                                    $quantity, 
                                    $negotiable, 
                                    $product_age, 
                                    $contact_email, 
                                    $home_number, 
                                    $mobile_number, 
                                    $pref_contact_timing, 
                                    $fcat_id, 
                                    $fsubcat_id, 
                                    $farea_id, 
                                    $fcity_id, 
                                    $fstate_id, 
                                    $fcountry_id)
        {
        $data = array(
                    'title' => $title,
                    'description'=>$description,
                    'price'=>$price, 
                    'quantity'=>$quantity, 
                    'negotiable'=>$negotiable, 
                    'product_age'=>$product_age, 
                    'contact_email'=>$contact_email, 
                    'home_number'=>$home_number, 
                    'mobile_number'=>$mobile_number, 
                    'pref_contact_timing'=>$pref_contact_timing, 
                    'fcat_id'=>$fcat_id, 
                    'fsubcat_id'=>$fsubcat_id, 
                    'farea_id'=>$farea_id, 
                    'fcity_id'=>$fcity_id, 
                    'fstate_id'=>$fstate_id, 
                    'fcountry_id'=>$fcountry_id,
                    );
        $this->update($data, 'listing_id = '. (int)$listing_id);
        }

    public function deleteListing($listing_id)
        {
        $this->delete('listing_id =' . (int)$listing_id);
        }
    }
?>