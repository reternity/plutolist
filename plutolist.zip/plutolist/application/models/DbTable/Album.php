<?php

class Application_Model_DbTable_Album extends Zend_Db_Table_Abstract
{

    protected $_name = 'pll_album';


}

